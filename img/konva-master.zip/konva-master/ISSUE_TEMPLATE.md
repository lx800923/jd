Thank you for submitting an issue!

Please make sure to check current open and closed issues to see if your question has been asked or answered before.
If you have just a question (not a bug or a feature request) it is better to ask it in [Stackoverflow](http://stackoverflow.com/questions/tagged/konvajs).

If you have a bug, please, try to create a reproducible example with jsfiddle (or any similar service).
You can use [this JSBIN](http://jsbin.com/xinabi/edit?html,js,output) as a template.
